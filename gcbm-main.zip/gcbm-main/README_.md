# 1. Introduction
This is the official repository for the paper "Revealing Combinatorial Reasoning of GNNs via Graph Concept Bottleneck Layer".

# 2. File Structure
The repository is structured as follows:
- interpretation/: Contains the scripts for explainability analysis and concept reasoning.
- main_.py: The implementation of graph classification on benchmark datasets.
- main_auc.py: The implementation of graph classification on large-scale imbalanced datasets.
- utils.py: The implementation of the utility functions.

# 3. Requirements
The code is written in Python 3.8.18. The main requirement packages are:

* numpy==1.23.5
* torch==1.11.0
* networkx==2.6.3
* igraph==0.10.8
* transformers==4.35.2
* datasets==2.15.0
* tokenizers==0.15.0
* scikit-learn==1.3.0
* tqdm==4.63.0
* gensim==4.0.1
* joblib==1.4.0
* pandas==1.2.4
* scipy==1.8.0
* pot==0.9.2

And all the running package environments are listed in the `environment.yaml` file. You can build the environment by running the following command; note that the packages are redundant.
**We recommend that you install the above packages manually.**

```bash
conda env create -f environment.yaml
```

# 4. Dataset Download
The datasets adopted in this work consist of benchmark datasets, large-scale imbalanced datasets, and explainable datasets. All datasets used in this paper can be downloaded from the official repository:
[here](https://chrsmrrs.github.io/datasets/docs/datasets/).

Alternatively, you can download the preprocessed datasets via our [anonymous link](https://anonymous.4open.science/r/Dataset_-5315/).

Combine the two split files `dataset_part_aa` and `dataset_part_ab` into the complete archive `dataset.zip` with the following command:
```bash
cat dataset_part_aa dataset_part_ab > dataset.zip
```
After decompressing `dataset.zip`, you will obtain two folders named `datasets` and `data`.


Specifically, the datasets folder contains benchmark datasets and large-scale imbalanced datasets, while the data folder contains datasets for interpretability experiments.

For correct program execution, place the `datasets` folder in the root directory of the `GCBM` project, and move the `data` folder into the interpretation directory for `explainability` experiments.


# 5. Usage

## 5.1. Classification on Benchmark Datasets
To run graph classification on benchmark datasets, you can use the following command:
```bash
python main_.py --dataset DHFR
```
This command will run the classification model on the DHFR dataset with default optimal parameters.
Other parameters are set to the default values, which can be found in the `main_.py` file.

## 5.2. Classification on Large-Scale Imbalanced Datasets
To run graph classification on large-scale imbalanced datasets, you can use the following command:
```bash
python main_auc.py --dataset MCF-7
```
This command will run the classification model on the MCF-7 dataset with default optimal parameters.
Other parameters are set to the default values, which can be found in the `main_auc.py` file.

## 5.3. Interpretation Experiments
To run the graph explainability experiments, you can use the following commands:
```bash
cd interpretation
python main.py --dataset solubility
```
This command will run the concept-based interpretation model on the solubility dataset.
Other parameters are set to the default values, which can be found in the `main.py` file.

---