import torch
import numpy as np
import random
import networkx as nx
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
from sklearn.model_selection import StratifiedKFold
from tokenizers.models import WordLevel
from tokenizers.trainers import WordLevelTrainer
from tokenizers import Tokenizer
from tokenizers.pre_tokenizers import WhitespaceSplit
from itertools import chain
from collections import OrderedDict
from functools import cmp_to_key
import itertools
import bfs_cbm as bfs
from src.datasets import  Mutag, Motif,SolubilityDataset,BenzeneDataset


def get_random_half(n):
    full_list = list(range(n + 1))
    half_count = (n + 1) // 2
    random_half = random.sample(full_list, half_count)
    return random_half


def data_to_networkx(data: Data, directed=False) -> nx.Graph:
    GraphClass = nx.DiGraph if directed else nx.Graph
    G = GraphClass()
    num_nodes = data.num_nodes
    G.add_nodes_from(range(num_nodes))

    if hasattr(data, 'x') and data.x is not None:
        for i in range(num_nodes):
            G.nodes[i]['feature'] = data.x[i].tolist()

    if hasattr(data, 'node_label') and data.node_label is not None:
        for i in range(num_nodes):
            G.nodes[i]['label'] = int(data.node_label[i].item())

    edge_index = data.edge_index.numpy()
    edges = list(zip(edge_index[0], edge_index[1]))
    G.add_edges_from(edges)

    if hasattr(data, 'edge_attr') and data.edge_attr is not None:
        for i, (u, v) in enumerate(edges):
            G.edges[u, v]['attr'] = data.edge_attr[i].tolist()

    if hasattr(data, 'edge_label') and data.edge_label is not None:
        for i, (u, v) in enumerate(edges):
            G.edges[u, v]['label'] = data.edge_label[i].item()

    if hasattr(data, 'y') and data.y is not None:
        G.graph['label'] = data.y.item() if data.y.dim() == 0 else data.y.tolist()

    if hasattr(data, 'ground_truth') and data.ground_truth is not None:
        G.graph['ground_truth'] = data.ground_truth.tolist()

    return G


def onehot_to_non_onehot(node_dict):
    sorted_node_ids = sorted(node_dict.keys())
    non_onehot_list = []

    for node_id in sorted_node_ids:
        onehot_feature = node_dict[node_id]['feature']
        non_onehot_val = onehot_feature.index(1.0)
        non_onehot_list.append(non_onehot_val)

    return np.array(non_onehot_list, dtype=np.int32)


def get_node_labels(graphs, label_type="label"):
    labels = {}
    for i, g in enumerate(graphs):
        if label_type == "label":
            labels[i] = onehot_to_non_onehot(g.nodes)
        elif label_type == "degree":
            labels[i] = np.array([g.degree(n) for n in g.nodes()])
        elif label_type == "uniform":
            labels[i] = np.ones(len(g.nodes()))
    return labels


def custom_sort(strings):
    def compare(s1, s2):
        list1 = list(map(int, s1.split(',')))
        list2 = list(map(int, s2.split(',')))

        for a, b in zip(list1, list2):
            if a != b:
                return a - b
        return len(list1) - len(list2)

    return sorted(strings, key=cmp_to_key(compare))


def convert_to_onehot_and_sum(all_labels_cluster_h):
    all_elements = np.concatenate(list(all_labels_cluster_h.values()))
    max_element = np.max(all_elements)

    result_dict = {}
    for key, arr in all_labels_cluster_h.items():
        onehot = np.zeros((len(arr), max_element + 1), dtype=int)
        onehot[np.arange(len(arr)), arr] = 1
        sum_vector = np.sum(onehot, axis=0)
        result_dict[key] = sum_vector

    return result_dict


def compute_entropy(labels):
    if len(labels) == 0:
        return 0
    unique_labels, counts = np.unique(labels, return_counts=True)
    probabilities = counts / len(labels)
    entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))
    return entropy


def compute_information_gain(dataset, labels, feature_idx):
    original_entropy = compute_entropy(labels)
    feature_values = dataset[:, feature_idx]
    threshold = np.mean(feature_values)
    mask = feature_values > threshold

    if np.all(mask) or np.all(~mask):
        return 0

    subset1_labels = labels[mask]
    subset2_labels = labels[~mask]

    weight1 = len(subset1_labels) / len(labels)
    weight2 = len(subset2_labels) / len(labels)

    entropy1 = compute_entropy(subset1_labels)
    entropy2 = compute_entropy(subset2_labels)
    conditional_entropy = weight1 * entropy1 + weight2 * entropy2
    information_gain = original_entropy - conditional_entropy
    return information_gain


def select_top_features(dataset, labels, n_top=3):
    n_features = dataset.shape[1]
    feature_scores = []

    for feature_idx in range(n_features):
        info_gain = compute_information_gain(dataset, labels, feature_idx)
        feature_scores.append((feature_idx, info_gain))

    feature_scores.sort(key=lambda x: x[1], reverse=True)
    return feature_scores[:n_top], feature_scores


def compute_bert_feats(
        graphs,
        maxh,
        depth,
        dataset,
        degree_of_all_graphs,
        label_type="label",
        out_batch_size=512,
        epoch=3,
        size=64,
        layer=4,
        head=4,
        random_state=42,
        save_model=False,
        max_length=113
):
    all_labels = {
        0: get_node_labels(graphs, label_type=label_type),
    }

    all_labels_cluster = {
        0: get_node_labels(graphs, label_type=label_type),
    }

    corpus = [[str(element) for element in array] for array in all_labels[0].values()]
    corpus_sort = [[all_labels[0][i][j] for j, _ in sorted(enumerate(degrees), key=lambda x: (-x[1], x[0]))] for i, degrees in enumerate(degree_of_all_graphs)]

    all_subtrees = {}
    all_subtrees[0] = {i: corpus[i] for i in range(len(corpus))}

    all_subtrees_sort = {}
    all_subtrees_sort[0] = {i: corpus_sort[i] for i in range(len(corpus_sort))}

    all_no_iso = []
    origin_no_iso = set()
    for g_origin_lbl in corpus:
        origin_no_iso.update(g_origin_lbl)
    origin_no_iso = custom_sort(list(origin_no_iso))
    all_no_iso.append(origin_no_iso)

    all_no_iso_bfs_no_neiber = []
    origin_no_iso_ = set()
    for g_origin_lbl in corpus:
        origin_no_iso_.update(g_origin_lbl)
    origin_no_iso_ = custom_sort(list(origin_no_iso_))
    all_no_iso_bfs_no_neiber.append(origin_no_iso_)

    num_graphs = len(graphs)
    for deep in range(1, 5):
        subtrees = {}
        subtrees_sort = {}
        no_iso = set()

        for gidx in range(num_graphs):
            g = graphs[gidx]
            num_nodes_of_g = g.number_of_nodes()
            degree_sort = degree_of_all_graphs[gidx]

            subtree_list = []
            for nidx in range(num_nodes_of_g):
                neighbors = []
                edges = list(bfs.bfs_edges(g, np.zeros(num_nodes_of_g), source=nidx, depth_limit=1))

                if edges:
                    for u, v in edges:
                        if u == edges[0][0]:
                            neighbors.append(v)
                    root_neib = [edges[0][0]] + sorted(neighbors)

                    neibs_label = []
                    root_label = list(all_labels.values())[-1][gidx][root_neib[0]]
                    for node in root_neib[1:]:
                        neib_label = list(all_labels.values())[-1][gidx][node]
                        neibs_label.append(neib_label)
                    node_label = [root_label] + sorted(neibs_label)
                    subtree = ','.join(str(x) for x in node_label)
                    subtree_list.append(subtree)

                if not edges:
                    root_label = list(all_labels.values())[-1][gidx][nidx]
                    node_label = [root_label]
                    subtree = ','.join(str(x) for x in node_label)
                    subtree_list.append(subtree)

            subtree_list_sort = [subtree for _, subtree in sorted(zip(degree_sort, subtree_list), key=lambda x: -x[0])]
            no_iso.update(subtree_list)
            subtrees[gidx] = subtree_list
            corpus.append(subtree_list)

            subtrees_sort[gidx] = subtree_list_sort
            corpus_sort.append(subtree_list_sort)

        no_iso = custom_sort(list(no_iso))
        all_no_iso_bfs_no_neiber.append(no_iso)
        flat_all_no_iso_ = list(OrderedDict.fromkeys(chain(*all_no_iso)))
        no_iso_ = [x for x in no_iso if x not in flat_all_no_iso_]
        all_no_iso.append(no_iso_)
        flat_all_no_iso = list(OrderedDict.fromkeys(chain(*all_no_iso)))

        all_labels[deep] = {}
        all_labels_cluster[deep] = {}
        for gid, lt in enumerate(subtrees.values()):
            all_labels[deep][gid] = np.array([flat_all_no_iso.index(t) for t in lt])
            all_labels_cluster[deep][gid] = np.array([no_iso.index(t) for t in lt])

        all_subtrees[deep] = subtrees
        all_subtrees_sort[deep] = subtrees_sort

    cls_of_gs_ = []
    for gidx, g in enumerate(graphs):
        cls_of_gs_.append(g.graph['label'])
    cls_of_gs = np.array(cls_of_gs_)

    topk_subtree_num = [len(no_iso_subtree) if len(no_iso_subtree) < 2 else 2 for no_iso_subtree in all_no_iso]

    all_concept_lib = []
    all_concept_lib_all = []
    for deep in range(1, 5):
        all_labels_cluster_h = all_labels_cluster[deep]
        g_num_subtree = convert_to_onehot_and_sum(all_labels_cluster_h)
        g_subtree = np.stack(list(g_num_subtree.values()), axis=0)
        top_features, all_feature = select_top_features(g_subtree, cls_of_gs, n_top=topk_subtree_num[deep])

        no_iso_deep = all_no_iso_bfs_no_neiber[deep]
        concept_lib_all = [no_iso_deep[idx] for idx, _ in all_feature]
        concept_lib = [no_iso_deep[idx] for idx, _ in top_features]
        corpus_sort.append(concept_lib)
        all_subtrees_sort[deep][len(graphs)] = concept_lib
        all_concept_lib.append(concept_lib)
        all_concept_lib_all.append(concept_lib_all)

    concept_lib_h4 = all_concept_lib[1]
    concept_lib_h4_all = all_concept_lib_all[1]
    subtrees_of_g_h4 = all_subtrees[2]
    important_node_gs = {}

    for key, value_list in subtrees_of_g_h4.items():
        indices = []
        for index, item in enumerate(value_list):
            if item in concept_lib_h4:
                indices.append(index)
        important_node_gs[key] = indices

    important_node_gs_subtree = []
    for gidx in range(num_graphs):
        g = graphs[gidx]
        num_nodes_of_g = g.number_of_nodes()
        important_node_g = important_node_gs[gidx]

        if len(important_node_g) > 0:
            import_node_list_g = []
            for nidx in important_node_g:
                edges = list(bfs.bfs_edges(g, np.zeros(num_nodes_of_g), source=nidx, depth_limit=2))
                flat_edges = sorted(set(itertools.chain(*edges)))
                import_node_list_g.append(flat_edges)

            flat_important_node_g = sorted(set(itertools.chain.from_iterable(import_node_list_g)))
            important_node_gs_subtree.append(torch.tensor(flat_important_node_g))
        else:
            flat_important_node_g = []
            important_node_gs_subtree.append(torch.tensor(flat_important_node_g))

    return important_node_gs_subtree


def get_gcbm_explainable_subgraph(data_dir, dataset_name, batch_size, splits, random_state, mutag_x=False):
    assert dataset_name in ['benzene', 'solubility']

    if dataset_name == 'benzene':
        dataset = BenzeneDataset(data_dir / 'benzene')
        split_idx = np.load(data_dir / 'benzene/benzene.npy', allow_pickle=True).item()
        loaders, test_set = get_loaders_and_test_set(batch_size, dataset=dataset, split_idx=split_idx)
        train_set = dataset[split_idx['train']]

    if dataset_name == 'solubility':
        dataset = SolubilityDataset(data_dir / 'solubility')
        split_idx = np.load(data_dir / 'solubility/solubility.npy', allow_pickle=True).item()
        loaders, test_set = get_loaders_and_test_set(batch_size, dataset=dataset, split_idx=split_idx)
        train_set = dataset[split_idx['train']]

    test_set_separate = []
    for i in range(len(test_set)):
        g_data = test_set[i]
        test_set_separate.append(g_data)

    test_set_networkx_separate = []
    degree_of_all_graphs = []
    for i in range(len(test_set)):
        g_data = test_set_separate[i]
        g_networkx = data_to_networkx(g_data)
        test_set_networkx_separate.append(g_networkx)
        degree_of_g = [g_networkx.degree(node) for node in range(g_networkx.number_of_nodes())]
        degree_of_all_graphs.append(degree_of_g)

    important_node_gs_subtree = compute_bert_feats(
        test_set_networkx_separate,
        3,
        2,
        dataset=None,
        degree_of_all_graphs=degree_of_all_graphs,
        random_state=random_state,
        label_type='label',
        size=4,
        epoch=3,
        layer=4,
        head=4,
        save_model=False,
        out_batch_size=64,
        max_length=64,
    )

    x_dim = test_set[0].x.shape[1]
    if isinstance(test_set, list):
        num_class = Batch.from_data_list(test_set).y.unique().shape[0]
    elif test_set.data.y.shape[-1] == 1 or len(test_set.data.y.shape) == 1:
        num_class = test_set.data.y.unique().shape[0]
    else:
        num_class = test_set.data.y.shape[-1]

    return loaders, test_set, x_dim, num_class, important_node_gs_subtree


def get_random_split_idx(dataset, dataset_name, splits):
    print('[INFO] Randomly split dataset!')
    idx = np.arange(len(dataset))
    np.random.shuffle(idx)

    if dataset_name == 'mutagenicity':
        print('[INFO] mutag_x is True!')
        n_train = int(splits['train'] * len(idx))
        train_idx, valid_idx = idx[:n_train], idx[n_train:]
        test_idx = [i for i in range(len(dataset)) if (dataset[i].y.squeeze() == 0 and dataset[i].edge_label.sum() > 0)]

    elif dataset_name == 'solubility':
        explainable_graphs = [i for i in range(len(dataset)) if (dataset[i].y.squeeze() == 1)]
        n_test = int(splits['test'] * len(idx))
        test_idx = random.sample(explainable_graphs, n_test)
        remaining_graphs = [i for i in idx if i not in test_idx]
        n_train = int(splits['train'] * len(idx))
        train_idx = random.sample(remaining_graphs, n_train)
        valid_idx = [i for i in remaining_graphs if i not in train_idx]

    else:
        n_train, n_valid = int(splits['train'] * len(idx)), int(splits['valid'] * len(idx))
        train_idx = idx[:n_train]
        valid_idx = idx[n_train:n_train + n_valid]
        test_idx = idx[n_train + n_valid:]

    return {'train': train_idx, 'valid': valid_idx, 'test': test_idx}


def get_loaders_and_test_set(batch_size, dataset=None, split_idx=None, dataset_splits=None):
    if split_idx is not None:
        assert dataset is not None
        train_loader = DataLoader(dataset[split_idx["train"]], batch_size=batch_size, shuffle=True)
        valid_loader = DataLoader(dataset[split_idx["valid"]], batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(dataset[split_idx["test"]], batch_size=2000, shuffle=False)
        test_set = dataset.copy(split_idx["test"])
    else:
        assert dataset_splits is not None
        train_loader = DataLoader(dataset_splits['train'], batch_size=batch_size, shuffle=True)
        valid_loader = DataLoader(dataset_splits['valid'], batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(dataset_splits['test'], batch_size=2000, shuffle=False)
        test_set = dataset_splits['test']
    return {'train': train_loader, 'valid': valid_loader, 'test': test_loader}, test_set