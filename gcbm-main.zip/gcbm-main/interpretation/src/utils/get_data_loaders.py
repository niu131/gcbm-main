import torch
import numpy as np
from torch_geometric.data import Batch
from torch_geometric.utils import degree
from torch_geometric.loader import DataLoader
from src.datasets import  Mutag, Motif,SolubilityDataset,BenzeneDataset
import random

import networkx as nx
from torch_geometric.data import Data
import os
import ot
import pandas as pd
import networkx as nx
from sklearn.metrics import make_scorer, accuracy_score
from sklearn.model_selection import ParameterGrid, StratifiedKFold
from sklearn.model_selection._validation import _fit_and_score
from sklearn.base import clone
from tokenizers.pre_tokenizers import Whitespace
from tokenizers.pre_tokenizers import WhitespaceSplit
from torch_geometric.data import Data
from gensim.models import Word2Vec
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score
from tokenizers.models import WordLevel
from tokenizers.trainers import WordLevelTrainer
from tokenizers import Tokenizer
from scipy.cluster.hierarchy import linkage, fcluster
import torch
from itertools import chain
from functools import cmp_to_key
from itertools import chain
from collections import OrderedDict
import math
import bfs_cbm as bfs
import itertools
import random



def get_random_half(n):
    # 生成0到n的列表（包含n）
    full_list = list(range(n + 1))
    # 计算需要挑选的元素数量（一半，向上取整）
    half_count = (n + 1) // 2  # 使用+1再//2实现向上取整
    # 随机挑选一半元素
    random_half = random.sample(full_list, half_count)
    return random_half




def data_to_networkx(data: Data, directed=False) -> nx.Graph:
    """
    将PyTorch Geometric的Data对象转换为NetworkX图

    参数:
        data: PyTorch Geometric的Data对象
        directed: 是否创建有向图，默认为无向图

    返回:
        nx.Graph或nx.DiGraph: 转换后的NetworkX图
    """
    # 根据是否有向选择图类型
    GraphClass = nx.DiGraph if directed else nx.Graph

    # 创建图
    G = GraphClass()

    # 添加节点
    num_nodes = data.num_nodes
    G.add_nodes_from(range(num_nodes))

    # 添加节点特征作为节点属性
    if hasattr(data, 'x') and data.x is not None:
        for i in range(num_nodes):
            # 将张量转换为列表以便NetworkX存储
            G.nodes[i]['feature'] = data.x[i].tolist()

    # 添加节点标签（如果存在）
    if hasattr(data, 'node_label') and data.node_label is not None:
        for i in range(num_nodes):
            G.nodes[i]['label'] = int(data.node_label[i].item())

    # 添加边
    edge_index = data.edge_index.numpy()
    edges = list(zip(edge_index[0], edge_index[1]))
    G.add_edges_from(edges)

    # 添加边属性（如果存在）
    if hasattr(data, 'edge_attr') and data.edge_attr is not None:
        for i, (u, v) in enumerate(edges):
            G.edges[u, v]['attr'] = data.edge_attr[i].tolist()


    # 添加边标签（如果存在）
    if hasattr(data, 'edge_label') and data.edge_label is not None:
        for i, (u, v) in enumerate(edges):
            G.edges[u, v]['label'] = data.edge_label[i].item()

    # 添加图级别属性
    if hasattr(data, 'y') and data.y is not None:
        G.graph['label'] = data.y.item() if data.y.dim() == 0 else data.y.tolist()

    # 添加ground_truth信息（节点重要性标识）
    if hasattr(data, 'ground_truth') and data.ground_truth is not None:
        # 将tensor转换为列表，保留原始的0.0和1.0值
        G.graph['ground_truth'] = data.ground_truth.tolist()

    return G


# 2. 核心函数：将独热向量转化为非独热索引（1所在的位置即为目标值）
def onehot_to_non_onehot(node_dict):
    # 按节点ID升序排序（确保0→1→2→…→9的顺序，与目标结果一致）
    sorted_node_ids = sorted(node_dict.keys())
    non_onehot_list = []

    for node_id in sorted_node_ids:
        # 获取当前节点的独热feature向量
        onehot_feature = node_dict[node_id]['feature']
        # 找到值为1.0的索引（即非独热值）
        non_onehot_val = onehot_feature.index(1.0)
        non_onehot_list.append(non_onehot_val)

    # 转化为ndarray
    return np.array(non_onehot_list, dtype=np.int32)



def get_node_labels(graphs, label_type="label"):
    """
    Get node labels from graphs
    """
    labels = {}
    for i, g in enumerate(graphs):
        if label_type == "label":
            # labels[i] = np.array([g.nodes[n]["label"] for n in g.nodes()])
            labels[i] = onehot_to_non_onehot(g.nodes)

        elif label_type == "degree":
            labels[i] = np.array([g.degree(n) for n in g.nodes()])
        elif label_type == "uniform":
            labels[i] = np.ones(len(g.nodes()))
    return labels


def custom_sort(strings):
    def compare(s1, s2):
        # 将字符串按逗号分割并转换为整数列表
        list1 = list(map(int, s1.split(',')))
        list2 = list(map(int, s2.split(',')))

        # 逐元素比较
        for a, b in zip(list1, list2):
            if a != b:
                return a - b

        # 如果前面的元素都相同，则长度较短的排前面
        return len(list1) - len(list2)

    return sorted(strings, key=cmp_to_key(compare))


def convert_to_onehot_and_sum(all_labels_cluster_h):
    """
    将字典中的每个元素转换为独热编码后逐行相加

    参数:
    all_labels_cluster_h (dict): 原始字典，值为numpy数组

    返回:
    dict: 转换并相加后的字典，值为求和后的数组
    """
    # 确定所有元素中的最大值
    all_elements = np.concatenate(list(all_labels_cluster_h.values()))
    max_element = np.max(all_elements)

    # 创建转换并相加后的字典
    result_dict = {}
    for key, arr in all_labels_cluster_h.items():
        # 创建全零矩阵并生成独热编码
        onehot = np.zeros((len(arr), max_element + 1), dtype=int)
        onehot[np.arange(len(arr)), arr] = 1

        # 逐行相加
        sum_vector = np.sum(onehot, axis=0)
        result_dict[key] = sum_vector

    return result_dict



def compute_entropy(labels):
    """计算标签列表的熵"""
    if len(labels) == 0:
        return 0
    unique_labels, counts = np.unique(labels, return_counts=True)
    probabilities = counts / len(labels)
    # 加微小值避免log(0)
    entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))
    return entropy



def compute_information_gain(dataset, labels, feature_idx):
    """计算某个特征(子树)的信息增益，使用该子树数量的平均值作为阈值"""
    # 计算原始熵（整体不确定性）
    original_entropy = compute_entropy(labels)

    # 获取当前子树在所有图中的数量
    feature_values = dataset[:, feature_idx]
    # 计算该子树数量的平均值作为划分阈值
    threshold = np.mean(feature_values)

    # 根据阈值划分数据集（大于均值为一类，否则为另一类）
    mask = feature_values > threshold  # True表示大于均值，False表示小于等于均值

    # 处理极端情况：所有样本都在同一划分中（信息增益为0）
    if np.all(mask) or np.all(~mask):
        return 0

    # 计算划分后两部分的标签
    subset1_labels = labels[mask]  # 子树数量>均值的图的标签
    subset2_labels = labels[~mask]  # 子树数量<=均值的图的标签

    # 计算两部分的权重（占总样本的比例）
    weight1 = len(subset1_labels) / len(labels)
    weight2 = len(subset2_labels) / len(labels)

    # 计算划分后的条件熵（加权平均熵）
    entropy1 = compute_entropy(subset1_labels)
    entropy2 = compute_entropy(subset2_labels)
    conditional_entropy = weight1 * entropy1 + weight2 * entropy2

    # 信息增益 = 原始熵 - 条件熵（不确定性减少量）
    information_gain = original_entropy - conditional_entropy
    return information_gain




def select_top_features(dataset, labels, n_top=3):
    """选择信息增益最高的前n种子树，使用每个子树的均值作为阈值"""
    n_features = dataset.shape[1]  # 33种子树
    feature_scores = []

    # 计算每种子树的信息增益
    for feature_idx in range(n_features):
        info_gain = compute_information_gain(dataset, labels, feature_idx)
        feature_scores.append((feature_idx, info_gain))

    # 按信息增益从大到小排序
    feature_scores.sort(key=lambda x: x[1], reverse=True)

    return feature_scores[:n_top], feature_scores # 返回前n种子树



def compute_bert_feats(
        graphs,
        maxh,
        depth,
        dataset,
        degree_of_all_graphs,
        label_type="label",
        out_batch_size=512,  #MUTAG:32，PROTEINS：256
        epoch=3,
        size=64,
        layer=4,
        head=4,
        random_state=42,
        save_model=False,
        max_length=113  #max_length=512,  MUTAG:30  ，PROTEINS：208  #IMDB-B：46，DHFR：71

):


    all_labels = {
        0: get_node_labels(graphs, label_type=label_type),
    }

    all_labels_cluster = {
        0: get_node_labels(graphs, label_type=label_type),
    }


    corpus = [[str(element) for element in array] for array in all_labels[0].values()]
    # corpus_sort = [[str(element) for element in array] for array in all_labels[0].values()]#########################
    corpus_sort = [[all_labels[0][i][j] for j, _ in sorted(enumerate(degrees), key=lambda x: (-x[1], x[0]))] for i, degrees in enumerate(degree_of_all_graphs)]

    # all_subtrees = []
    # all_subtrees.append(corpus)
    all_subtrees = {}
    all_subtrees[0] = {i: corpus[i] for i in range(len(corpus))}

    all_subtrees_sort = {}
    all_subtrees_sort[0] = {i: corpus_sort[i] for i in range(len(corpus_sort))}############################

    all_no_iso = []
    origin_no_iso = set()
    for g_origin_lbl in corpus:
        origin_no_iso.update(g_origin_lbl)
    origin_no_iso = custom_sort(list(origin_no_iso))
    all_no_iso.append(origin_no_iso)

    all_no_iso_bfs_no_neiber = []
    origin_no_iso_ = set()
    for g_origin_lbl in corpus:
        origin_no_iso_.update(g_origin_lbl)
    origin_no_iso_ = custom_sort(list(origin_no_iso_))
    all_no_iso_bfs_no_neiber.append(origin_no_iso_)


    num_graphs = len(graphs)  # 该数据集中的图的数量
    # for deep in range(1, maxh):

    for deep in range(1, 5):  ##############################
        subtrees = {}
        subtrees_sort = {}
        no_iso = set()


        for gidx in range(num_graphs):
            g = graphs[gidx]
            num_nodes_of_g = g.number_of_nodes()
            degree_sort = degree_of_all_graphs[gidx]

            subtree_list = []
            for nidx in range(num_nodes_of_g):
                neighbors = []
                edges = list(bfs.bfs_edges(g, np.zeros(num_nodes_of_g), source=nidx, depth_limit=1))

                if edges:
                    for u, v in edges:
                        if u == edges[0][0]:
                            neighbors.append(v)
                    root_neib = [edges[0][0]] + sorted(neighbors)

                    neibs_label = []
                    root_label = list(all_labels.values())[-1][gidx][root_neib[0]]
                    for node in root_neib[1:]:
                        neib_label = list(all_labels.values())[-1][gidx][node]
                        neibs_label.append(neib_label)
                    node_label = [root_label] + sorted(neibs_label)
                    subtree = ','.join(str(x) for x in node_label)
                    subtree_list.append(subtree)

                if not edges:
                    #print('第n个图的第m个节点', gidx, nidx)
                    root_label = list(all_labels.values())[-1][gidx][nidx]
                    node_label = [root_label]
                    subtree = ','.join(str(x) for x in node_label)
                    subtree_list.append(subtree)

            # 先将两个列表打包成元组列表，再按degree降序排序，最后提取subtree元素
            subtree_list_sort = [subtree for _, subtree in sorted(zip(degree_sort, subtree_list), key=lambda x: -x[0])]
            no_iso.update(subtree_list)
            subtrees[gidx] = subtree_list
            corpus.append(subtree_list)

            subtrees_sort[gidx] = subtree_list_sort
            corpus_sort.append(subtree_list_sort)

        no_iso = custom_sort(list(no_iso))
        all_no_iso_bfs_no_neiber.append(no_iso)
        flat_all_no_iso_ = list(OrderedDict.fromkeys(chain(*all_no_iso)))
        no_iso_ = [x for x in no_iso if x not in flat_all_no_iso_]
        all_no_iso.append(no_iso_)
        flat_all_no_iso = list(OrderedDict.fromkeys(chain(*all_no_iso)))


        all_labels[deep] = {}
        all_labels_cluster[deep] = {}
        for gid, lt in enumerate(subtrees.values()):
            all_labels[deep][gid] = np.array([flat_all_no_iso.index(t) for t in lt])
            all_labels_cluster[deep][gid] = np.array([no_iso.index(t) for t in lt])

        all_subtrees[deep] = subtrees
        all_subtrees_sort[deep] =subtrees_sort
    # all_subtrees[0][188]=all_subtrees[0][187]   #验证
    #要用的是all_subtrees_sort和corpus_sort


    #筛选
    cls_of_gs_ = []
    for gidx, g in enumerate(graphs):
        cls_of_gs_.append(g.graph['label'])
    cls_of_gs = np.array(cls_of_gs_)

    topk_subtree_num = [len(no_iso_subtree) if len(no_iso_subtree)<2 else 2 for no_iso_subtree in all_no_iso]
                    #最好是10个关键概念，83.4
#

    all_concept_lib =[]
    all_concept_lib_all = []  ######
    for deep in range(1, 5):

        all_labels_cluster_h = all_labels_cluster[deep]############################这里用的是all_labels_cluster，不是all_labels，
        # 举例：在all_labels_cluster中，'0'的标签是0，'0，0，0'的标签是1，'0,0,1'的标签是2，     在all_labels中，'0'的标签是0，‘1’的标签是1，‘2’的标签是2，'0，0，0'的标签是3，'0,0,1'的标签是4
        g_num_subtree = convert_to_onehot_and_sum(all_labels_cluster_h)

        g_subtree = np.stack(list(g_num_subtree.values()), axis=0)    #对于PO..数据集，g_subtree形状是1113*297

        top_features, all_feature = select_top_features(g_subtree, cls_of_gs, n_top=topk_subtree_num[deep])   ######最新的：添加了第二个输出

        no_iso_deep = all_no_iso_bfs_no_neiber[deep]

        concept_lib_all = [no_iso_deep[idx] for idx, _ in all_feature]  #####
        concept_lib = [no_iso_deep[idx] for idx, _ in top_features]
        corpus_sort.append(concept_lib)
        all_subtrees_sort[deep][len(graphs)] = concept_lib
        all_concept_lib.append(concept_lib)
        all_concept_lib_all.append(concept_lib_all)  ####


        # print(1)


    # concept_lib_h4 = all_concept_lib[3]
    # subtrees_of_g_h4 = all_subtrees[4]

    concept_lib_h4 = all_concept_lib[1]
    concept_lib_h4_all = all_concept_lib_all[1]
    subtrees_of_g_h4 = all_subtrees[2]
    # 创建新字典存储结果
    important_node_gs = {}

    # 遍历subtrees_of_g_h4中的每个键值对
    for key, value_list in subtrees_of_g_h4.items():
        # 存储当前键对应的所有符合条件的索引
        indices = []
        # 遍历列表中的每个元素及其索引
        for index, item in enumerate(value_list):
            # 检查元素是否存在于concept_lib_h4中
            if item in concept_lib_h4:
                indices.append(index)
        # 将结果添加到新字典中
        important_node_gs[key] = indices



    # #填补important_node_gs中的空列表
    # # 步骤1：找到important_node_gs中空列表的键
    # empty_keys = [k for k, v in important_node_gs.items() if len(v) == 0]
    #
    # # 步骤2：遍历每个空列表的键，处理替换逻辑
    # for key in empty_keys:
    #     # 取出subtrees_of_g_h4中对应键的值
    #     list_x = subtrees_of_g_h4.get(key, [])
    #     if not list_x:
    #         print(f"subtrees_of_g_h4中键{key}的值为空，无法处理")
    #         continue
    #
    #     # 步骤3：记录list_x中每个元素在concept_lib_h4_all中的索引（仅保留存在的）
    #     elem_index = []
    #     for idx, elem in enumerate(list_x):
    #         if elem in concept_lib_h4_all:
    #             lib_idx = concept_lib_h4_all.index(elem)
    #             elem_index.append((lib_idx, idx))  # (在concept_lib中的索引, 在list_x中的索引)
    #
    #     # 步骤4：按concept_lib中的索引升序排序，取前两个list_x的索引
    #     elem_index.sort(key=lambda x: x[0])
    #     top_two = [item[1] for item in elem_index[:5]]
    #
    #     # 步骤5：替换important_node_gs中的空列表
    #     important_node_gs[key] = top_two





    important_node_gs_subtree = []
    for gidx in range(num_graphs):
        g = graphs[gidx]
        num_nodes_of_g = g.number_of_nodes()
        important_node_g = important_node_gs[gidx]

        if len(important_node_g)>0:
            import_node_list_g = []
            for nidx in important_node_g:
                neighbors = []
                edges = list(bfs.bfs_edges(g, np.zeros(num_nodes_of_g), source=nidx, depth_limit=2))  #2   [(0,1),(0,2),(0,3)]
                flat_edges = sorted(set(itertools.chain(*edges)))    #[0,1,2,3]
                import_node_list_g.append(flat_edges)

            flat_important_node_g = sorted(set(itertools.chain.from_iterable(import_node_list_g)))   #一个图中所有的重要节点
            important_node_gs_subtree.append(torch.tensor(flat_important_node_g))

        else:
            flat_important_node_g = []
            important_node_gs_subtree.append(torch.tensor(flat_important_node_g))



    return important_node_gs_subtree





def get_data_loaders(data_dir, dataset_name, batch_size, splits, random_state, mutag_x=False):
    assert dataset_name in ['benzene','solubility']

    if dataset_name == 'benzene':
        dataset = BenzeneDataset(data_dir/'benzene')
        split_idx = np.load(data_dir/'benzene/benzene.npy',allow_pickle=True).item()
        loaders, test_set = get_loaders_and_test_set(batch_size, dataset=dataset, split_idx=split_idx)
        train_set = dataset[split_idx['train']]

    if dataset_name == 'solubility':
        dataset = SolubilityDataset(data_dir/'solubility' )
        split_idx = np.load(data_dir/'solubility/solubility.npy',allow_pickle=True).item()
        # split_idx = get_random_split_idx(dataset, dataset_name, splits)
        loaders, test_set = get_loaders_and_test_set(batch_size, dataset=dataset, split_idx=split_idx)
        train_set = dataset[split_idx['train']]

    # elif dataset_name == 'mutagenicity':
    #     dataset = Mutag(root=data_dir / 'mutag')
    #     split_idx = np.load(data_dir/'mutag/mutagen.npy',allow_pickle=True).item()
    #     loaders, test_set = get_loaders_and_test_set(batch_size, dataset=dataset, split_idx=split_idx)
    #     train_set = dataset[split_idx['train']]
    #
    # elif dataset_name == 'labeled-motifs' :
    #     train_set = Motif(root=data_dir / dataset_name, mode='train')
    #     valid_set = Motif(root=data_dir / dataset_name, mode='val')
    #     test_set = Motif(root=data_dir / dataset_name, mode='test')      #我们检验的时候，就只用test数据集，生成关键字图，然后计算auc
    #     loaders, test_set = get_loaders_and_test_set(batch_size, dataset_splits={'train': train_set, 'valid': valid_set, 'test': test_set})

    test_set_separate = []
    for i in range(len(test_set)):
        g_data = test_set[i]
        test_set_separate.append(g_data)

    test_set_networkx_separate = []
    degree_of_all_graphs = []
    for i in range(len(test_set)):
        g_data = test_set_separate[i]
        g_networkx = data_to_networkx(g_data)
        test_set_networkx_separate.append(g_networkx)

        degree_of_g = [g_networkx.degree(node) for node in range(g_networkx.number_of_nodes())]
        degree_of_all_graphs.append(degree_of_g)


##############################
    important_node_gs_subtree = compute_bert_feats(
        test_set_networkx_separate, #graphs,
        3,
        2,
        dataset=None,
        degree_of_all_graphs=degree_of_all_graphs,
        random_state=random_state,
        label_type='label',
        #label_type='degree',   #label_type='label'
        size=4,
        epoch=3,
        layer=4,
        head=4,
        save_model=False,
        out_batch_size=64,
        max_length=64,
    )


#########################


    x_dim = test_set[0].x.shape[1]
    if isinstance(test_set, list):
        num_class = Batch.from_data_list(test_set).y.unique().shape[0]
    elif test_set.data.y.shape[-1] == 1 or len(test_set.data.y.shape) == 1:
        num_class = test_set.data.y.unique().shape[0]
    else:
        num_class = test_set.data.y.shape[-1]

    return loaders, test_set, x_dim, num_class, important_node_gs_subtree


def get_random_split_idx(dataset,dataset_name, splits):
   

    print('[INFO] Randomly split dataset!')
    idx = np.arange(len(dataset))
    np.random.shuffle(idx)

    if dataset_name == 'mutagenicity':
        print('[INFO] mutag_x is True!')
        n_train = int(splits['train'] * len(idx))
        train_idx, valid_idx = idx[:n_train], idx[n_train:]
        test_idx = [i for i in range(len(dataset)) if (dataset[i].y.squeeze() == 0 and dataset[i].edge_label.sum() > 0)]
    
    elif dataset_name == 'solubility':
        explainable_graphs = [i for i in range(len(dataset)) if (dataset[i].y.squeeze() == 1)]
        n_test = int(splits['test'] * len(idx))
        test_idx = random.sample(explainable_graphs, n_test)
        # Remaining graphs for training and validation
        remaining_graphs = [i for i in idx if i not in test_idx]
        n_train = int(splits['train'] * len(idx))
        train_idx = random.sample(remaining_graphs, n_train)
        valid_idx = [i for i in remaining_graphs if i not in train_idx]
        
        
    else:
        n_train, n_valid = int(splits['train'] * len(idx)), int(splits['valid'] * len(idx))
        train_idx = idx[:n_train]
        valid_idx = idx[n_train:n_train+n_valid]
        test_idx = idx[n_train+n_valid:]
    
        
    
        
    return {'train': train_idx, 'valid': valid_idx, 'test': test_idx}




def get_loaders_and_test_set(batch_size, dataset=None, split_idx=None, dataset_splits=None):
    if split_idx is not None:
        assert dataset is not None
        train_loader = DataLoader(dataset[split_idx["train"]], batch_size=batch_size, shuffle=True)
        valid_loader = DataLoader(dataset[split_idx["valid"]], batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(dataset[split_idx["test"]], batch_size=2000, shuffle=False)
        test_set = dataset.copy(split_idx["test"])  # For visualization
    else:
        assert dataset_splits is not None
        train_loader = DataLoader(dataset_splits['train'], batch_size=batch_size, shuffle=True)
        valid_loader = DataLoader(dataset_splits['valid'], batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(dataset_splits['test'], batch_size=2000, shuffle=False)           #test数据集
        test_set = dataset_splits['test']  # For visualization
    return {'train': train_loader, 'valid': valid_loader, 'test': test_loader}, test_set
