import sys
sys.path.append('../src')
import os
# os.environ["CUDA_VISIBLE_DEVICES"] = '5'
import torch
import torch.nn as nn
from copy import deepcopy
from pathlib import Path
from model import CIFlow    # A surrogate model that can be replaced with any other model.
from base_model import CIFlow_base   #A surrogate model that can be replaced with any other model.
from src.utils import set_seed, generate_A_L_W_all, get_gcbm_explainable_subgraph
from trainer import run_one_epoch
import argparse
import numpy as np

def args_parser():  
    parser = argparse.ArgumentParser(description='CIFlow-GNN')
    parser.add_argument('--lambda_con', type=float, default=0.05)
    parser.add_argument('--lambda_fea', type=float, default=0.01)
    parser.add_argument('--lambda_2', type=float, default=1.0)
    parser.add_argument('--lambda_proto', type=float, default=0.05)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--epochs', type=int, default=1)
    parser.add_argument('--clusters', type=int, default=4)
    parser.add_argument('--layer_num', type=int, default=5)
    parser.add_argument('--blocks_num', type=int, default=1)
    parser.add_argument('--num_graph_filter', type=int, default=5)
    parser.add_argument('--hidden_size', type=int, default=64)
    parser.add_argument('--dropout', type=float, default=0.3)
    parser.add_argument('--result_folder',  type=str, default='mini_results', help='results folder')
    parser.add_argument('--important_c', type=int, default=1, help='select top c clusters as important subgraph')
    parser.add_argument('--dataset_name', type=str, default='solubility', help='solubility/benzene')
    args = parser.parse_args()
    return args




args = args_parser()
dataset_name = args.dataset_name

model_name= 'CIFlow'
seed = args.seed
set_seed(args.seed)
data_dir = Path('./data')
device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    
# load dataset and data splits #Notice!! “important_node_gs_subtree” denotes our processed output, which is directly adopted for AUC computation and is independent of the surrogate model.
loaders, test_set, x_dim, num_class, important_node_gs_subtree = get_gcbm_explainable_subgraph(data_dir, dataset_name, batch_size=128, random_state=seed,
                                                                                splits={'train': 0.8, 'valid': 0.1, 'test': 0.1}, 
                                                                                mutag_x=True if dataset_name == 'benzene' else False)
  
# CIFlow-GNN model  #It serves as a surrogate model for code execution and is independent of our key graph extraction method; it can be replaced with any other alternative model.
CIFlow_base_model = CIFlow_base(args, x_dim, num_class).to(device)   #

# optimizer
optimizer = torch.optim.Adam(list(CIFlow_base_model.parameters()), lr=1e-3, weight_decay=3.0e-6)

# loss function
CIFlow_model = CIFlow(args,CIFlow_base_model, optimizer)

# precompute adj matrices, laplacian matrices, and normalized adjacency matrice with self-loops
A_val,L_val, W_val = generate_A_L_W_all(loaders['valid'])
A_test,L_test, W_test = generate_A_L_W_all(loaders['test'])

# record the results
ResultFolderPATH = args.result_folder +'/'+dataset_name+ '/'  \
    + 'lambda_con' + str(args.lambda_con)+ '/'  \
    + 'lambda_fea' + str(args.lambda_fea)+ '/'  \
    + 'lambda_proto' + str(args.lambda_proto)+ '/'  \
    + 'lambda_2' + str(args.lambda_2)+ '/'  \
    + 'layer_num' + str(args.layer_num)+ '/'  \
    + 'blocks_num' + str(args.blocks_num)+ '/' \
    + 'important_c' + str(args.important_c)+ '/'  \
    + 'clusters' + str(args.clusters)+ '/'  \
    + 'num_graph_filter' + str(args.num_graph_filter)+ '/' \
    + 'seed' + str(args.seed)+ '/'
if not os.path.exists(ResultFolderPATH):
    os.makedirs(ResultFolderPATH)


acc_per_epoch = np.zeros((args.epochs, 1))
for epoch in range(args.epochs):
    #Our method does not require training models, and directly tests
    test_loss, test_auc = run_one_epoch(A_test, L_test, W_test, CIFlow_model, loaders['test'], epoch, 'test', dataset_name, is_test=True, is_train = False, important_node_gs_subtree=important_node_gs_subtree)

    # acc_per_epoch[epoch][0] = valid_loss
    acc_per_epoch[epoch][0] = test_auc

    with open(ResultFolderPATH + '/acc_results.txt', 'a+') as f:
        f.write(str(acc_per_epoch[epoch][0]) + ' ')
        # f.write(str(acc_per_epoch[epoch][1]) + '\n')

    print('='*50)
    print('='*50)

ind = np.argmin(acc_per_epoch[:,0])
auc = acc_per_epoch[ind,0]
print(f'The final ROC AUC for dataset {dataset_name} is : {auc:.3f}.')

