import argparse
import os
import sys
import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Linear, Sequential, BatchNorm1d, ReLU, Dropout
from torch.optim.lr_scheduler import MultiStepLR, ReduceLROnPlateau
from torch_geometric.nn import GCNConv, GINConv, global_mean_pool, global_add_pool
from torch_geometric.loader import DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from tqdm import tqdm

from IPython.display import Javascript, display

from utils_ import (
    load_data_ori,
    convert_networkx_to_pyg,
    compute_bert_feats
)

try:
    display(Javascript('''google.colab.output.setIframeHeight(0, true, {maxHeight: 300})'''))
except:
    pass

# ==============================================
# GIN Model
# ==============================================
class GIN(torch.nn.Module):
    def __init__(self, hidden_channels, num_node_classes, num_class_of_dataset, dropout_rate, num_concept_all_deep):
        super(GIN, self).__init__()
        torch.manual_seed(12345)

        self.conv1 = GINConv(
            Sequential(Linear(num_node_classes, hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[0]), ReLU()))
        self.res1 = GINConv(
            Sequential(Linear(num_node_classes, num_concept_all_deep[0]),
                       BatchNorm1d(num_concept_all_deep[0]), ReLU()))
        self.bn1 = torch.nn.BatchNorm1d(num_concept_all_deep[0])

        self.conv2 = GINConv(
            Sequential(Linear(num_concept_all_deep[0], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[1]), ReLU()))
        self.res2 = GINConv(
            Sequential(Linear(num_concept_all_deep[0], num_concept_all_deep[1]),
                       BatchNorm1d(num_concept_all_deep[1]), ReLU()))
        self.bn2 = torch.nn.BatchNorm1d(num_concept_all_deep[1])

        self.conv3 = GINConv(
            Sequential(Linear(num_concept_all_deep[1], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[2]), ReLU()))
        self.bn3 = torch.nn.BatchNorm1d(num_concept_all_deep[2])

        self.conv4 = GINConv(
            Sequential(Linear(num_concept_all_deep[2], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[3]), ReLU()))
        self.bn4 = torch.nn.BatchNorm1d(num_concept_all_deep[3])

        self.weights = torch.nn.Parameter(torch.tensor([1.0, 1.0, 1.0, 1.0], dtype=torch.float32))
        self.residual_weights = torch.nn.Parameter(torch.ones(4))
        self.sparse_lin = Linear(sum(num_concept_all_deep), sum(num_concept_all_deep))
        self.lin1 = Linear(sum(num_concept_all_deep), num_class_of_dataset)
        self.dropout_rate = dropout_rate

    def forward(self, x, edge_index, batch):
        h1 = self.conv1(x, edge_index) + self.residual_weights[0] * self.res1(x, edge_index)
        h1 = self.bn1(h1)
        h1 = F.dropout(h1, p=self.dropout_rate, training=self.training)

        h2 = self.conv2(h1, edge_index) + self.residual_weights[1] * self.res2(h1, edge_index)
        h2 = self.bn2(h2)
        h2 = F.dropout(h2, p=self.dropout_rate, training=self.training)

        h3 = self.conv3(h2, edge_index) + self.residual_weights[2] * h2
        h3 = self.bn3(h3)
        h3 = F.dropout(h3, p=self.dropout_rate, training=self.training)

        h4 = self.conv4(h3, edge_index) + self.residual_weights[3] * h3
        h4 = self.bn4(h4)
        h4 = F.dropout(h4, p=self.dropout_rate, training=self.training)

        h1 = global_add_pool(h1, batch)
        h2 = global_add_pool(h2, batch)
        h3 = global_add_pool(h3, batch)
        h4 = global_add_pool(h4, batch)

        norm_weights = F.softmax(self.weights, dim=0)
        h1 = h1 * norm_weights[0]
        h2 = h2 * norm_weights[1]
        h3 = h3 * norm_weights[2]
        h4 = h4 * norm_weights[3]

        concept_pred = torch.cat((h1, h2, h3, h4), dim=1)
        concept_pred = self.sparse_lin(concept_pred)

        h = concept_pred.relu()
        h = self.lin1(h)
        out = F.dropout(h, p=self.dropout_rate, training=self.training)

        return concept_pred, out

class GIN_P(torch.nn.Module):
    def __init__(self, hidden_channels, num_node_classes, num_class_of_dataset, dropout_rate, num_concept_all_deep):
        super(GIN_P, self).__init__()
        torch.manual_seed(12345)

        self.conv1 = GINConv(
            Sequential(Linear(num_node_classes, hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[0]), ReLU()))
        self.res1 = GINConv(
            Sequential(Linear(num_node_classes, num_concept_all_deep[0]),
                       BatchNorm1d(num_concept_all_deep[0]), ReLU()))
        self.bn1 = torch.nn.BatchNorm1d(num_concept_all_deep[0])

        self.conv2 = GINConv(
            Sequential(Linear(num_concept_all_deep[0], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[1]), ReLU()))
        self.res2 = GINConv(
            Sequential(Linear(num_concept_all_deep[0], num_concept_all_deep[1]),
                       BatchNorm1d(num_concept_all_deep[1]), ReLU()))
        self.bn2 = torch.nn.BatchNorm1d(num_concept_all_deep[1])

        self.conv3 = GINConv(
            Sequential(Linear(num_concept_all_deep[1], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[2]), ReLU()))
        self.bn3 = torch.nn.BatchNorm1d(num_concept_all_deep[2])

        self.conv4 = GINConv(
            Sequential(Linear(num_concept_all_deep[2], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[3]), ReLU()))
        self.bn4 = torch.nn.BatchNorm1d(num_concept_all_deep[3])

        self.weights = torch.nn.Parameter(torch.tensor([1.0, 1.0, 1.0, 1.0], dtype=torch.float32))
        self.residual_weights = torch.nn.Parameter(torch.ones(4))
        self.sparse_lin = Linear(sum(num_concept_all_deep), sum(num_concept_all_deep))
        self.lin1 = Linear(sum(num_concept_all_deep), num_class_of_dataset)
        self.dropout_rate = dropout_rate

    def forward(self, x, edge_index, batch):
        h1 = self.conv1(x, edge_index) + self.residual_weights[0] * self.res1(x, edge_index)
        h1 = self.bn1(h1)
        h1 = F.dropout(h1, p=self.dropout_rate, training=self.training)

        h2 = self.conv2(h1, edge_index) + self.residual_weights[1] * h1
        h2 = self.bn2(h2)
        h2 = F.dropout(h2, p=self.dropout_rate, training=self.training)

        h3 = self.conv3(h2, edge_index) + self.residual_weights[2] * h2
        h3 = self.bn3(h3)
        h3 = F.dropout(h3, p=self.dropout_rate, training=self.training)

        h4 = self.conv4(h3, edge_index) + self.residual_weights[3] * h3
        h4 = self.bn4(h4)
        h4 = F.dropout(h4, p=self.dropout_rate, training=self.training)

        h1 = global_add_pool(h1, batch)
        h2 = global_add_pool(h2, batch)
        h3 = global_add_pool(h3, batch)
        h4 = global_add_pool(h4, batch)

        norm_weights = F.softmax(self.weights, dim=0)
        h1 = h1 * norm_weights[0]
        h2 = h2 * norm_weights[1]
        h3 = h3 * norm_weights[2]
        h4 = h4 * norm_weights[3]

        concept_pred = torch.cat((h1, h2, h3, h4), dim=1)
        concept_pred = self.sparse_lin(concept_pred)

        h = concept_pred.relu()
        h = self.lin1(h)
        out = F.dropout(h, p=self.dropout_rate, training=self.training)

        return concept_pred, out

# ==============================================
# Main Function
# ==============================================
def main(
        dataset,
        maxh,
        depth,
        label_type="label",
        data_path="datasets",
        crossvalidation=True,
        random_state=42,
        size=64,
        layer=4,
        head=4,
        epoch=3,
        save_model=False,

        out_batch_size=64,
        max_length=64,

        lr=0.00018959140692027812,
        weight_decay=0.0007852121474359662,
        sparse_reg_coef=0.0002245158776565872,
        max_grad_norm=1.2829153819299346,
        dropout_rate=0.5157767681464404,

        lr_factor=0.6757968797215829,
        lr_patience=36,
        lr_cooldown=6,
        lr_threshold=0.1,
        lr_min_lr=1e-6,

        train_batch_size=64,
        num_epochs=299
):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Equipment used: {device}")

    graphs, num_node_classes, num_class_of_dataset, degree_of_all_graphs = load_data_ori(dataset, data_path)
    print("Data loading completed!")

    start = time.time()

    node_enbed, graph_embeds, _, _, num_concept_all_deep = compute_bert_feats(
        graphs, maxh, depth,
        num_node_classes=num_node_classes,
        dataset=dataset,
        num_class_of_dataset=num_class_of_dataset,
        degree_of_all_graphs=degree_of_all_graphs,
        random_state=random_state, label_type=label_type,
        size=size, epoch=epoch, layer=layer, head=head,
        save_model=save_model, out_batch_size=out_batch_size,
        max_length=max_length, device=device
    )

    concept = [np.array(row) for row in np.hstack([sub for sub in graph_embeds]).tolist()]
    Data_graphs = []
    for i, g in enumerate(graphs):
        g.graph["concept_lbl"] = concept[i]
        Data_g = convert_networkx_to_pyg(g, num_node_classes)
        Data_graphs.append(Data_g)

    if crossvalidation:
        g_y_labels = np.array([data.y.item() for data in Data_graphs])
        skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
        train_test_indices = []
        for train_idx, test_idx in skf.split(X=np.zeros(len(g_y_labels)), y=g_y_labels):
            train_test_indices.append((train_idx, test_idx))

        train_test_datasets = []
        for train_idx, test_idx in train_test_indices:
            train_dataset = [Data_graphs[i] for i in train_idx]
            test_dataset = [Data_graphs[i] for i in test_idx]
            train_test_datasets.append((train_dataset, test_dataset))

        train_test_loaders = []
        for train_dataset, test_dataset in train_test_datasets:
            train_loader = DataLoader(train_dataset, batch_size=train_batch_size, shuffle=True)
            test_loader = DataLoader(test_dataset, batch_size=train_batch_size, shuffle=False)
            train_test_loaders.append((train_loader, test_loader))
    else:
        print('Please set crossvalidation=True')
        sys.exit()

    epoch_accuracies = [[] for _ in range(num_epochs)]
    epoch_acc = []

    for fold, (train_loader, test_loader) in enumerate(train_test_loaders, 1):
        print('='*60)
        print(f"Fold {fold} training starts")
        fold_acc = []

        # ================== MODEL SELECTION ==================
        if dataset == "MUTAG":
            model = GIN(
                hidden_channels=64,
                num_node_classes=num_node_classes,
                num_class_of_dataset=num_class_of_dataset,
                dropout_rate=dropout_rate,
                num_concept_all_deep=num_concept_all_deep
            ).to(device)
        else:
            model = GIN_P(
                hidden_channels=64,
                num_node_classes=num_node_classes,
                num_class_of_dataset=num_class_of_dataset,
                dropout_rate=dropout_rate,
                num_concept_all_deep=num_concept_all_deep
            ).to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
        criterion_ce = nn.CrossEntropyLoss()
        criterion_mse = nn.MSELoss()

        scheduler = ReduceLROnPlateau(
            optimizer, mode='max', factor=lr_factor, patience=lr_patience,
            threshold=lr_threshold, cooldown=lr_cooldown, min_lr=lr_min_lr, verbose=True
        )

        def train(loader):
            model.train()
            total_loss = 0
            correct = 0
            for data in loader:
                data = data.to(device)
                concept_pred, out = model(data.x, data.edge_index, data.batch)

                loss1 = criterion_ce(out, data.y)
                loss2 = criterion_mse(concept_pred, data.concept_lbl)
                sparse_loss = sparse_reg_coef * torch.norm(model.sparse_lin.weight, p=1)
                loss = loss1 + loss2 + sparse_loss

                total_loss += loss.item()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
                optimizer.step()
                optimizer.zero_grad()

                pred = out.argmax(dim=1)
                correct += int((pred == data.y).sum())
            return total_loss / len(loader), correct / len(loader.dataset)

        def test(loader):
            model.eval()
            correct = 0
            with torch.no_grad():
                for data in loader:
                    data = data.to(device)
                    _, out = model(data.x, data.edge_index, data.batch)
                    pred = out.argmax(dim=1)
                    correct += int((pred == data.y).sum())
            return correct / len(loader.dataset)

        for epoch in range(1, num_epochs + 1):
            train_loss, train_acc = train(train_loader)
            test_acc = test(test_loader)
            scheduler.step(test_acc)

            print(f'Epoch: {epoch:03d} | Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.4f} | Test Acc: {test_acc:.4f}')
            epoch_accuracies[epoch-1].append(test_acc)
            if epoch % 5 == 0:
                fold_acc.append(test_acc)

        epoch_acc.append(fold_acc)
        print('='*60)

    # ================== OUTPUT SELECTION ==================
    acc = np.array(epoch_acc).max(axis=1)
    acc1_mean = acc.mean()
    acc1_std = acc.std()

    epoch_average_accuracies = [sum(accs) / len(accs) for accs in epoch_accuracies]
    best_epoch_accuracy = max(epoch_average_accuracies)
    best_index = epoch_average_accuracies.index(best_epoch_accuracy)
    best_fold = epoch_accuracies[best_index]
    acc2_mean = np.mean(best_fold)
    acc2_std = np.std(best_fold)

    # Judge dataset
    small_datasets = ["MUTAG", "PTC-MR", "BZR", "DHFR", "COX2"]
    if dataset in small_datasets:
        print("\n" + "="*60)
        print(f"Using Method 1: Best per fold accuracy")
        print(f"Validation Accuracy: {acc1_mean:.4f} +- {acc1_std:.4f}")
        final_mean = acc1_mean
        final_std = acc1_std
    else:
        print("\n" + "="*60)
        print(f"Using Method 2: Best epoch across all folds")
        print(f"Best Epoch Accuracy: {best_epoch_accuracy:.4f}")
        print(f"10-fold average accuracy: {acc2_mean*100:.2f} +- {acc2_std*100:.2f} %")
        final_mean = acc2_mean
        final_std = acc2_std

    end = time.time()
    print(f"Total time: {end-start:.2f}s")
    return final_mean, final_std, end-start

# ==============================================
# Dataset Config
# ==============================================
DATASET_CONFIGS = {
    "MUTAG": {
        "maxh": 5, "depth": 2, "out_batch_size": 32, "max_length": 64,
        "lr": 0.011395315501374015, "weight_decay": 9.2516614469223e-06,
        "sparse_reg_coef": 0.0038331254120727225, "max_grad_norm": 0.8817014017035498,
        "dropout_rate": 0.4909420038417461, "lr_factor": 0.5699292820551017,
        "lr_patience": 53, "lr_cooldown": 5
    },
    "BZR": {  #
        "maxh": 5, "depth": 2, "out_batch_size": 64, "max_length": 64,
        "lr": 0.002727929369841776, "weight_decay": 0.0004981899393600415, "sparse_reg_coef": 0.0057089471456330835,
        "max_grad_norm": 0.9203737464179176, "dropout_rate": 0.36180985719816205,
        "lr_factor": 0.39220384115475015, "lr_patience": 56, "lr_cooldown": 7
    },
    "PTC-MR": {   #
        "maxh": 5, "depth": 2, "out_batch_size": 64, "max_length": 64,
        "lr": 0.0002530593132761568, "weight_decay": 0.00027214031500464545, "sparse_reg_coef": 0.003550653147557239,
        "max_grad_norm": 1.1755856806867968, "dropout_rate": 0.5221177641394418,
        "lr_factor": 0.3099370887737809, "lr_patience": 29, "lr_cooldown": 7
    },
    "COX2": {   #
        "maxh": 5, "depth": 2, "out_batch_size": 64, "max_length": 64,
        "lr": 0.009520145760425397, "weight_decay": 0.0001610128003061733, "sparse_reg_coef": 0.0005544489207170327,
        "max_grad_norm": 2.649669052478696, "dropout_rate": 0.5419518599986969,
        "lr_factor": 0.4731489987517901, "lr_patience": 48, "lr_cooldown": 5
    },
    "IMDB-BINARY": {  #
        "maxh": 5, "depth": 2, "out_batch_size": 64, "max_length": 64,
        "lr": 0.00018959140692027812, "weight_decay": 0.0007852121474359662, "sparse_reg_coef": 0.0002245158776565872,
        "max_grad_norm": 1.2829153819299346, "dropout_rate": 0.5157767681464404,
        "lr_factor": 0.6757968797215829, "lr_patience": 36, "lr_cooldown": 6
    },
    "IMDB-MULTI": {  #
        "maxh": 5, "depth": 2, "out_batch_size": 64, "max_length": 64,
        "lr": 0.00018959140692027812, "weight_decay": 0.0007852121474359662, "sparse_reg_coef": 0.0002245158776565872,
        "max_grad_norm": 1.2829153819299346, "dropout_rate": 0.5157767681464404,
        "lr_factor": 0.6757968797215829, "lr_patience": 36, "lr_cooldown": 6
    },
    "COLLAB": {  #
        "maxh": 5, "depth": 2, "out_batch_size": 64, "max_length": 360,
        "lr": 0.00019885731855556911, "weight_decay": 0.0006010289411931519, "sparse_reg_coef": 0.00047714317525463336,
        "max_grad_norm": 1.83235172240891, "dropout_rate": 0.4950913053597766,
        "lr_factor": 0.6137219606723854, "lr_patience": 35, "lr_cooldown": 5
    },
    "DHFR": {  #
        "maxh": 5, "depth": 2, "out_batch_size": 64, "max_length": 71,  #"max_length": 360,
        "lr": 0.005767367592990959, "weight_decay": 4.6569702437803834e-05, "sparse_reg_coef": 0.00905795142575853,
        "max_grad_norm": 1.2844828937815849, "dropout_rate": 0.20157600811591742,
        "lr_factor": 0.7210772342191472, "lr_patience": 46, "lr_cooldown": 11
    },
    "DBLP_v1": {  #
        "maxh": 5, "depth": 2, "out_batch_size": 512, "max_length": 64,
        "lr": 8.32929189e-05, "weight_decay": 7.11447601e-05, "sparse_reg_coef": 2.91063591e-04,
        "max_grad_norm": 6.3879, "dropout_rate": 0.2624,
        "lr_factor": 0.4624, "lr_patience": 16, "lr_cooldown": 18
    },
}

# ==============================================
# Run
# ==============================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="DHFR")  #IMDB-MULTI
    args = parser.parse_args()

    config = DATASET_CONFIGS[args.dataset]
    mean_acc, std_acc, total_time = main(
        dataset=args.dataset,
        maxh=config["maxh"],
        depth=config["depth"],
        out_batch_size=config["out_batch_size"],
        max_length=config["max_length"],
        lr=config["lr"],
        weight_decay=config["weight_decay"],
        sparse_reg_coef=config["sparse_reg_coef"],
        max_grad_norm=config["max_grad_norm"],
        dropout_rate=config["dropout_rate"],
        lr_factor=config["lr_factor"],
        lr_patience=config["lr_patience"],
        lr_cooldown=config["lr_cooldown"]
    )

    print("\n" + "="*60)
    print(f"{args.dataset} Training completed!")
    print(f"Final Accuracy: {mean_acc:.4f} +- {std_acc:.4f}")