import os
import ot
import pandas as pd
import networkx as nx
import time
import numpy as np
from sklearn.model_selection import StratifiedKFold
from tokenizers.models import WordLevel
from tokenizers.trainers import WordLevelTrainer
from tokenizers import Tokenizer
from torch_geometric.data import Data
import torch
from itertools import chain
from collections import OrderedDict
from functools import cmp_to_key
import bfs_cbm as bfs
from transformers import (
    BertConfig,
    BertForMaskedLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    BertModel,
    PreTrainedTokenizerFast,
)
from datasets import Dataset
from tokenizers.pre_tokenizers import Whitespace
from tokenizers.pre_tokenizers import WhitespaceSplit


def load_data_ori(dataset, data_path='datasets'):
    """
    Load dataset from the datasets folder.
    Read graph structure, node labels, graph labels from standard TUDataset format files.
    """
    print('Loading {} dataset...'.format(dataset))
    adj_file = os.path.join(data_path, dataset, dataset + '_A.txt')
    graph_id_file = os.path.join(data_path, dataset, dataset + '_graph_indicator.txt')
    graph_label_file = os.path.join(data_path, dataset, dataset + '_graph_labels.txt')
    node_label_file = os.path.join(data_path, dataset, dataset + '_node_labels.txt')
    node_attr_file = os.path.join(data_path, dataset, dataset + '_node_attributes.txt')
    edge_label_file = os.path.join(data_path, dataset, dataset + '_edge_labels.txt')
    edge_attr_file = os.path.join(data_path, dataset, dataset + '_edge_attributes.txt')

    if not os.path.exists(adj_file):
        raise FileNotFoundError(f'Dataset {dataset} not found.')

    has_label = False
    has_attr = False
    has_edge_attr = False
    has_edge_label = False

    if os.path.exists(adj_file):
        adj = pd.read_csv(adj_file, header=None, index_col=None).values
    if os.path.exists(graph_id_file):
        graph_indicator = pd.read_csv(graph_id_file, header=None, index_col=None).values
    if os.path.exists(graph_label_file):
        graph_label = pd.read_csv(graph_label_file, header=None, index_col=None).values
        num_class_of_dataset = len(set(tuple(x) for x in graph_label))
    if os.path.exists(node_label_file):
        node_label = pd.read_csv(node_label_file, header=None, index_col=None).values
        has_label = True
        elements = [x[0] for x in node_label]
        unique_elements = set(elements)
        num_node_classes = len(unique_elements)
    if os.path.exists(node_attr_file):
        node_attr = pd.read_csv(node_attr_file, header=None, index_col=None).values
        has_attr = True
    if os.path.exists(edge_label_file):
        edge_label = pd.read_csv(edge_label_file, header=None, index_col=None).values
        has_edge_label = True
    if os.path.exists(edge_attr_file):
        edge_attr = pd.read_csv(edge_attr_file, header=None, index_col=None).values
        has_edge_attr = True

    graphs = []
    num_graph = np.max(graph_indicator)
    edge_ind = 0
    degree_of_all_g = []

    # Adjust graph labels to 0-based
    if num_class_of_dataset == 2:
        graph_label0_1 = [[0 if x == -1 or x == 2 else x for x in sublist] for sublist in graph_label]
    else:
        graph_label0_1 = [[x - 1 for x in sublist] for sublist in graph_label]

    for i in range(num_graph):
        g = nx.Graph()
        g.graph['label'] = graph_label0_1[i][0]
        g.graph['id'] = i

        # Add nodes
        node_indicator = np.where(graph_indicator == i + 1)[0]
        node_indicator = node_indicator + 1
        for node in node_indicator:
            g.add_node(node)
            if has_label:
                g.nodes[node]['label'] = node_label[node - 1][0]
            if has_attr:
                g.nodes[node]['attr'] = node_attr[node - 1]

        # Add edges
        while edge_ind < len(adj):
            edge = adj[edge_ind]
            if edge[0] in node_indicator and edge[1] in node_indicator:
                g.add_edge(edge[0], edge[1])
                if has_edge_attr:
                    g.edges[edge[0], edge[1]]['attr'] = edge_attr[edge_ind][0]
                edge_ind += 1
            else:
                break

        # Convert node IDs to start from 0
        g = nx.convert_node_labels_to_integers(g, first_label=0)
        node_labels = [g.degree[node] for node in g.nodes()]
        degree_of_all_g.append(node_labels)
        graphs.append(g)

    # If no node labels exist, use node degree as node labels
    if not has_label:
        flat_list = [item for sublist in degree_of_all_g for item in sublist]
        unique_elements = sorted(list(set(flat_list)))
        num_node_classes = len(unique_elements)
        element_to_index = {element: index for index, element in enumerate(unique_elements)}
        new_degree_of_all_g = [[element_to_index[item] for item in sublist] for sublist in degree_of_all_g]

        for i in range(num_graph):
            g = graphs[i]
            node_degree_lbl = new_degree_of_all_g[i]
            nx.set_node_attributes(g, dict(zip(g.nodes(), node_degree_lbl)), 'label')
            graphs[i] = g

    return graphs, num_node_classes, num_class_of_dataset, degree_of_all_g


def get_node_labels(graphs, label_type="label"):
    """
    Get node labels (or degree) from graph nodes.
    """
    labels = {}
    for i, g in enumerate(graphs):
        if label_type == "label":
            labels[i] = np.array([g.nodes[n]["label"] for n in g.nodes()])
        elif label_type == "degree":
            labels[i] = np.array([g.degree(n) for n in g.nodes()])
        elif label_type == "uniform":
            labels[i] = np.ones(len(g.nodes()))
    return labels


def custom_sort(strings):
    """
    Custom sort for subtree string structures (split by comma, compare element-wise).
    """
    def compare(s1, s2):
        list1 = list(map(int, s1.split(',')))
        list2 = list(map(int, s2.split(',')))

        for a, b in zip(list1, list2):
            if a != b:
                return a - b
        return len(list1) - len(list2)

    return sorted(strings, key=cmp_to_key(compare))


def convert_to_onehot_and_sum(all_labels_cluster_h):
    """
    Convert label array to one-hot encoding and sum across nodes to get graph-level features.
    """
    all_elements = np.concatenate(list(all_labels_cluster_h.values()))
    max_element = np.max(all_elements)

    result_dict = {}
    for key, arr in all_labels_cluster_h.items():
        onehot = np.zeros((len(arr), max_element + 1), dtype=int)
        onehot[np.arange(len(arr)), arr] = 1
        sum_vector = np.sum(onehot, axis=0)
        result_dict[key] = sum_vector

    return result_dict


def compute_entropy(labels):
    """Compute entropy of a label list for information gain calculation."""
    if len(labels) == 0:
        return 0
    unique_labels, counts = np.unique(labels, return_counts=True)
    probabilities = counts / len(labels)
    entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))
    return entropy


def compute_information_gain(dataset, labels, feature_idx):
    """
    Compute information gain for a given subtype feature using mean as threshold.
    """
    original_entropy = compute_entropy(labels)
    feature_values = dataset[:, feature_idx]
    threshold = np.mean(feature_values)
    mask = feature_values > threshold

    if np.all(mask) or np.all(~mask):
        return 0

    subset1_labels = labels[mask]
    subset2_labels = labels[~mask]

    weight1 = len(subset1_labels) / len(labels)
    weight2 = len(subset2_labels) / len(labels)

    entropy1 = compute_entropy(subset1_labels)
    entropy2 = compute_entropy(subset2_labels)
    conditional_entropy = weight1 * entropy1 + weight2 * entropy2
    information_gain = original_entropy - conditional_entropy

    return information_gain


def select_top_features(dataset, labels, n_top=3):
    """
    Select top-k most informative subtrees using information gain.
    """
    n_features = dataset.shape[1]
    feature_scores = []

    for feature_idx in range(n_features):
        info_gain = compute_information_gain(dataset, labels, feature_idx)
        feature_scores.append((feature_idx, info_gain))

    feature_scores.sort(key=lambda x: x[1], reverse=True)
    return feature_scores[:n_top]


def calculate_cosine_similarity(graph_embeddings_h, subtrees_embedding_h):
    """
    Compute cosine similarity between graph embeddings and concept embeddings.
    """
    subtrees_array = np.array(subtrees_embedding_h)
    subtrees_norms = np.linalg.norm(subtrees_array, axis=1)
    result_list = []

    for graph_vector in graph_embeddings_h:
        graph_norm = np.linalg.norm(graph_vector)
        if graph_norm == 0:
            similarities = np.zeros(len(subtrees_embedding_h))
        else:
            dot_products = np.dot(subtrees_array, graph_vector)
            similarities = dot_products / (graph_norm * subtrees_norms)
        result_list.append(similarities)

    return result_list


def compute_bert_feats(
        graphs,
        maxh,
        depth,
        num_node_classes,
        dataset,
        num_class_of_dataset,
        degree_of_all_graphs,
        label_type="label",
        out_batch_size=512,
        epoch=3,
        size=64,
        layer=4,
        head=4,
        random_state=42,
        save_model=False,
        max_length=71,
        device=None
):
    """
    Extract concept features using BERT:
    1. Extract subtree structures via BFS
    2. Select informative concepts via information gain
    3. Train BERT to compute embeddings for graphs and concepts
    4. Output graph-concept similarity as final concept features
    """
    start1 = time.time()
    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    all_labels = {
        0: get_node_labels(graphs, label_type=label_type),
    }

    all_labels_cluster = {
        0: get_node_labels(graphs, label_type=label_type),
    }

    corpus = [[str(element) for element in array] for array in all_labels[0].values()]
    corpus_sort = [[all_labels[0][i][j] for j, _ in sorted(enumerate(degrees), key=lambda x: (-x[1], x[0]))] for i, degrees in enumerate(degree_of_all_graphs)]

    all_subtrees = {}
    all_subtrees[0] = {i: corpus[i] for i in range(len(corpus))}
    all_subtrees_sort = {}
    all_subtrees_sort[0] = {i: corpus_sort[i] for i in range(len(corpus_sort))}

    all_no_iso = []
    origin_no_iso = set()
    for g_origin_lbl in corpus:
        origin_no_iso.update(g_origin_lbl)
    origin_no_iso = custom_sort(list(origin_no_iso))
    all_no_iso.append(origin_no_iso)

    all_no_iso_bfs_no_neiber = []
    origin_no_iso_ = set()
    for g_origin_lbl in corpus:
        origin_no_iso_.update(g_origin_lbl)
    origin_no_iso_ = custom_sort(list(origin_no_iso_))
    all_no_iso_bfs_no_neiber.append(origin_no_iso_)

    num_graphs = len(graphs)

    for deep in range(1, 5):
        subtrees = {}
        subtrees_sort = {}
        no_iso = set()

        for gidx in range(num_graphs):
            g = graphs[gidx]
            num_nodes_of_g = g.number_of_nodes()
            degree_sort = degree_of_all_graphs[gidx]
            subtree_list = []

            for nidx in range(num_nodes_of_g):
                neighbors = []
                edges = list(bfs.bfs_edges(g, np.zeros(num_nodes_of_g), source=nidx, depth_limit=1))

                if edges:
                    for u, v in edges:
                        if u == edges[0][0]:
                            neighbors.append(v)
                    root_neib = [edges[0][0]] + sorted(neighbors)
                    neibs_label = []
                    root_label = list(all_labels.values())[-1][gidx][root_neib[0]]
                    for node in root_neib[1:]:
                        neib_label = list(all_labels.values())[-1][gidx][node]
                        neibs_label.append(neib_label)
                    node_label = [root_label] + sorted(neibs_label)
                    subtree = ','.join(str(x) for x in node_label)
                    subtree_list.append(subtree)
                else:
                    root_label = list(all_labels.values())[-1][gidx][nidx]
                    node_label = [root_label]
                    subtree = ','.join(str(x) for x in node_label)
                    subtree_list.append(subtree)

            subtree_list_sort = [subtree for _, subtree in sorted(zip(degree_sort, subtree_list), key=lambda x: -x[0])]
            no_iso.update(subtree_list)
            subtrees[gidx] = subtree_list
            corpus.append(subtree_list)
            subtrees_sort[gidx] = subtree_list_sort
            corpus_sort.append(subtree_list_sort)

        no_iso = custom_sort(list(no_iso))
        all_no_iso_bfs_no_neiber.append(no_iso)
        flat_all_no_iso_ = list(OrderedDict.fromkeys(chain(*all_no_iso)))
        no_iso_ = [x for x in no_iso if x not in flat_all_no_iso_]
        all_no_iso.append(no_iso_)
        flat_all_no_iso = list(OrderedDict.fromkeys(chain(*all_no_iso)))

        all_labels[deep] = {}
        all_labels_cluster[deep] = {}
        for gid, lt in enumerate(subtrees.values()):
            all_labels[deep][gid] = np.array([flat_all_no_iso.index(t) for t in lt])
            all_labels_cluster[deep][gid] = np.array([no_iso.index(t) for t in lt])

        all_subtrees[deep] = subtrees
        all_subtrees_sort[deep] = subtrees_sort

    end1 = time.time()
    print(f"total time1: {end1 - start1} s")

    start2 = time.time()

    # Collect graph labels for concept selection
    cls_of_gs_ = []
    for gidx, g in enumerate(graphs):
        cls_of_gs_.append(g.graph['label'])
    cls_of_gs = np.array(cls_of_gs_)

    topk_subtree_num = [len(no_iso_subtree) if len(no_iso_subtree) < 64 else 64 for no_iso_subtree in all_no_iso]

    # Select top concepts using information gain
    for deep in range(1, 5):
        all_labels_cluster_h = all_labels_cluster[deep]
        g_num_subtree = convert_to_onehot_and_sum(all_labels_cluster_h)
        g_subtree = np.stack(list(g_num_subtree.values()), axis=0)
        top_features = select_top_features(g_subtree, cls_of_gs, n_top=topk_subtree_num[deep])
        no_iso_deep = all_no_iso_bfs_no_neiber[deep]
        concept_lib = [no_iso_deep[idx] for idx, _ in top_features]
        corpus_sort.append(concept_lib)
        all_subtrees_sort[deep][len(graphs)] = concept_lib

    end2 = time.time()
    print(f"total time2: {end2 - start2} s")

    # Prepare corpus for BERT training
    corpus_sort_ = corpus_sort[len(graphs):]
    all_subtrees_sort_ = {i: v for i, (_, v) in enumerate(list(all_subtrees_sort.items())[1:])}

    model_file = f"transformers_g/{dataset}"
    if not os.path.exists(model_file):
        os.makedirs(model_file)
    model_file = f"{model_file}/bert_K{maxh}_H{depth}_s{size}_l{layer}_h{head}_e{epoch}_node"

    start3 = time.time()

    if not os.path.exists(model_file):
        print("Training BERT model by MLM 15% ...")
        text_corpus = [" ".join(c) for c in corpus_sort_]
        transformer_dataset = Dataset.from_dict({"text": text_corpus})
        transformer_dataset = transformer_dataset.train_test_split(test_size=0.1, seed=42)

        tokenizer_path = f"transformers_g/tokenizers"
        if not os.path.exists(tokenizer_path):
            os.makedirs(tokenizer_path)
        tokenizer_path += f"/tokenizer_{dataset}_K{maxh}_H{depth}.json"

        if not os.path.exists(tokenizer_path):
            tokenizer = Tokenizer(WordLevel(unk_token="[UNK]"))
            tokenizer.pre_tokenizer = WhitespaceSplit()
            token_trainer = WordLevelTrainer(
                special_tokens=["[UNK]", "[PAD]", "[CLS]", "[SEP]", "[MASK]"]
            )
            tokenizer.train_from_iterator(text_corpus, token_trainer)
            tokenizer.save(tokenizer_path)

        tokenizer = PreTrainedTokenizerFast(
            tokenizer_file=tokenizer_path,
            unk_token="[UNK]",
            pad_token="[PAD]",
            cls_token="[CLS]",
            sep_token="[SEP]",
            mask_token="[MASK]",
        )

        def tokenize_function(examples):
            return tokenizer(
                examples["text"],
                padding="max_length",
                truncation=True,
                max_length=max_length,
            )

        tokenized_dataset = transformer_dataset.map(
            tokenize_function, batched=True, num_proc=4
        )

        config = BertConfig(
            vocab_size=tokenizer.vocab_size,
            hidden_size=size,
            num_hidden_layers=layer,
            num_attention_heads=head,
            max_position_embeddings=max_length,
        )

        model = BertForMaskedLM(config)
        out_path = f"transformers_g/log/{dataset}/model_log"
        if not os.path.exists(out_path):
            os.makedirs(out_path)

        training_args = TrainingArguments(
            output_dir=out_path,
            per_device_train_batch_size=64,
            per_device_eval_batch_size=64,
            num_train_epochs=epoch,
            seed=random_state,
            evaluation_strategy="epoch",
            overwrite_output_dir=True,
            logging_strategy="no",
            report_to="none",
        )

        data_collator = DataCollatorForLanguageModeling(
            tokenizer=tokenizer, mlm_probability=0.15
        )

        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=tokenized_dataset["train"],
            eval_dataset=tokenized_dataset["test"],
            data_collator=data_collator,
        )

        trainer.train()
        model = model.bert

        if save_model:
            model.save_pretrained(model_file)
            tokenizer.save_pretrained(model_file)

    else:
        print(f"Loading pre-trained BERT model on {dataset} with K={maxh}, H={depth}, size={size}, layer={layer}, head={head}, epoch={epoch}")
        model = BertModel.from_pretrained(model_file)
        tokenizer = PreTrainedTokenizerFast.from_pretrained(model_file)

    model.eval()
    model.to("cuda")

    node_embeddings = []
    subtrees_embedding = []
    num_nodes = [len(g.nodes()) for g in graphs]

    for deep in range(4):
        dth_corpus = []
        graph_subtree_h = all_subtrees_sort_[deep]
        graph_sentences = []
        for gid, g_subtrees in enumerate(graph_subtree_h.values()):
            graph_sentences.append(" ".join(g_subtrees))
        dth_corpus.extend(graph_sentences)

        inputs = tokenizer(
            dth_corpus,
            padding="max_length",
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        )

        num_batches = int(len(dth_corpus) // out_batch_size + 1) if len(dth_corpus) % out_batch_size != 0 else int(len(dth_corpus) // out_batch_size)
        new_embeddings_ = []

        with torch.no_grad():
            model.eval()
            inputs = {k: v.to("cuda") for k, v in inputs.items()}
            for i in range(num_batches):
                batch_inputs = {
                    k: v[i * out_batch_size: (i + 1) * out_batch_size]
                    for k, v in inputs.items()
                }

                batch_num_node = []
                for seq in batch_inputs['input_ids']:
                    first_one = (seq == 1).nonzero(as_tuple=True)[0]
                    if first_one.numel() > 0:
                        batch_num_node.append(first_one[0].item())
                    else:
                        batch_num_node.append(seq.size(0))

                outputs = model(**batch_inputs)
                batch_node_embeddings = []
                for i, length in enumerate(batch_num_node):
                    truncated_hidden = outputs.last_hidden_state[i, :length, :]
                    batch_node_embeddings.append(truncated_hidden)

                new_embeddings_.extend([tensor.cpu().tolist() for tensor in batch_node_embeddings])

        new_embeddings = new_embeddings_[:len(graphs)]
        subtrees_embed = new_embeddings_[-1]
        subtrees_embedding.append(subtrees_embed)
        node_embeddings.append([np.array(sublist) for sublist in new_embeddings])

    # Compute graph embedding by sum pooling
    graph_embeddings = []
    for h in range(len(node_embeddings)):
        n_enbed_h = node_embeddings[h]
        g_enbed_h = [np.sum(arr, axis=0) for arr in n_enbed_h]
        graph_embeddings.append(g_enbed_h)

    # Compute graph-concept cosine similarity
    graph_concept_sim = []
    for h in range(len(graph_embeddings)):
        graph_embeddings_h = graph_embeddings[h]
        subtrees_embedding_h = subtrees_embedding[h]
        similarity_list = calculate_cosine_similarity(graph_embeddings_h, subtrees_embedding_h)
        graph_concept_sim.append(similarity_list)

    end3 = time.time()
    print(f"total time3: {end3 - start3} s")

    return node_embeddings, graph_concept_sim, graph_embeddings, subtrees_embedding, topk_subtree_num[1:]


def convert_networkx_to_pyg(g, num_node_classes):
    """
    Convert a NetworkX graph to PyTorch Geometric Data object.
    Node features: one-hot node labels
    Edge index: undirected graph (bidirectional edges)
    """
    node_labels = []
    has_node_label = False

    for node, data in g.nodes(data=True):
        if 'label' in data:
            has_node_label = True
            node_labels.append(data['label'])

    if not has_node_label:
        degrees = [g.degree(node) for node in g.nodes()]
    else:
        x = torch.zeros(len(node_labels), num_node_classes)
        for i, label in enumerate(node_labels):
            if 0 <= label < num_node_classes:
                x[i, label] = 1.0

    edge_index = []
    for edge in g.edges():
        edge_index.append([edge[0], edge[1]])
        edge_index.append([edge[1], edge[0]])

    edge_index = torch.tensor(edge_index, dtype=torch.long).t().contiguous()
    sorted_indices = edge_index[0].argsort()
    edge_index = edge_index[:, sorted_indices]

    graph_label = g.graph.get('label', 0)
    y = torch.tensor([graph_label], dtype=torch.long)

    concept_lbl = g.graph.get('concept_lbl')
    concept_lbl = torch.tensor(concept_lbl, dtype=torch.float32).unsqueeze(0)

    data = Data(x=x, edge_index=edge_index, y=y, concept_lbl=concept_lbl)
    return data