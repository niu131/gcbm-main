import argparse
import os
import sys
import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Linear, Sequential, BatchNorm1d, ReLU, Dropout
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch_geometric.nn import GINConv, global_add_pool
from torch_geometric.loader import DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score
from tqdm import tqdm

from IPython.display import Javascript, display

from utils_ import (
    load_data_ori,
    convert_networkx_to_pyg,
    compute_bert_feats
)

try:
    display(Javascript('''google.colab.output.setIframeHeight(0, true, {maxHeight: 300})'''))
except:
    pass

#
def ranking_loss(pred_scores, labels):
    pos_scores = pred_scores[labels == 1]
    neg_scores = pred_scores[labels == 0]

    if len(pos_scores) == 0 or len(neg_scores) == 0:
        return torch.tensor(0.0, device=pred_scores.device)

    pos_neg_pairs = 1.0 - (pos_scores.unsqueeze(1) - neg_scores.unsqueeze(0))
    loss = torch.mean(torch.clamp(pos_neg_pairs, min=0.0))
    return loss

# ==============================================
# GIN_P Model
# ==============================================
class GIN_P(torch.nn.Module):
    def __init__(self, hidden_channels, num_node_classes, num_class_of_dataset, dropout_rate, num_concept_all_deep):
        super(GIN_P, self).__init__()
        torch.manual_seed(12345)

        self.conv1 = GINConv(
            Sequential(Linear(num_node_classes, hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[0]), ReLU()))
        self.res1 = GINConv(
            Sequential(Linear(num_node_classes, num_concept_all_deep[0]),
                       BatchNorm1d(num_concept_all_deep[0]), ReLU()))
        self.bn1 = torch.nn.BatchNorm1d(num_concept_all_deep[0])

        self.conv2 = GINConv(
            Sequential(Linear(num_concept_all_deep[0], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[1]), ReLU()))
        self.res2 = GINConv(
            Sequential(Linear(num_concept_all_deep[0], num_concept_all_deep[1]),
                       BatchNorm1d(num_concept_all_deep[1]), ReLU()))
        self.bn2 = torch.nn.BatchNorm1d(num_concept_all_deep[1])

        self.conv3 = GINConv(
            Sequential(Linear(num_concept_all_deep[1], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[2]), ReLU()))
        self.bn3 = torch.nn.BatchNorm1d(num_concept_all_deep[2])

        self.conv4 = GINConv(
            Sequential(Linear(num_concept_all_deep[2], hidden_channels),
                       BatchNorm1d(hidden_channels), ReLU(),
                       Linear(hidden_channels, num_concept_all_deep[3]), ReLU()))
        self.bn4 = torch.nn.BatchNorm1d(num_concept_all_deep[3])

        self.weights = torch.nn.Parameter(torch.tensor([1.0, 1.0, 1.0, 1.0], dtype=torch.float32))
        self.residual_weights = torch.nn.Parameter(torch.ones(4))
        self.sparse_lin = Linear(sum(num_concept_all_deep), sum(num_concept_all_deep))
        self.lin1 = Linear(sum(num_concept_all_deep), 1)
        self.dropout_rate = dropout_rate

    def forward(self, x, edge_index, batch):
        h1 = self.conv1(x, edge_index) + self.residual_weights[0] * self.res1(x, edge_index)
        h1 = self.bn1(h1)
        h1 = F.dropout(h1, p=self.dropout_rate, training=self.training)

        h2 = self.conv2(h1, edge_index) + self.residual_weights[1] * h1
        h2 = self.bn2(h2)
        h2 = F.dropout(h2, p=self.dropout_rate, training=self.training)

        h3 = self.conv3(h2, edge_index) + self.residual_weights[2] * h2
        h3 = self.bn3(h3)
        h3 = F.dropout(h3, p=self.dropout_rate, training=self.training)

        h4 = self.conv4(h3, edge_index) + self.residual_weights[3] * h3
        h4 = self.bn4(h4)
        h4 = F.dropout(h4, p=self.dropout_rate, training=self.training)

        h1 = global_add_pool(h1, batch)
        h2 = global_add_pool(h2, batch)
        h3 = global_add_pool(h3, batch)
        h4 = global_add_pool(h4, batch)

        norm_weights = F.softmax(self.weights, dim=0)
        h1 = h1 * norm_weights[0]
        h2 = h2 * norm_weights[1]
        h3 = h3 * norm_weights[2]
        h4 = h4 * norm_weights[3]

        concept_pred = torch.cat((h1, h2, h3, h4), dim=1)
        concept_pred = self.sparse_lin(concept_pred)

        h = concept_pred.relu()
        h = self.lin1(h)
        out = F.dropout(h, p=self.dropout_rate, training=self.training).squeeze(1)

        return concept_pred, out

# ==============================================
# Main Function
# ==============================================
def main(
        dataset,
        maxh,
        depth,
        label_type="label",
        data_path="datasets",
        crossvalidation=True,
        random_state=42,
        size=64,
        layer=4,
        head=4,
        epoch=3,
        save_model=False,

        out_batch_size=64,
        max_length=64,

        lr=0.000132965214572995,
        weight_decay=0.00014817820606039095,
        sparse_reg_coef=0.00026471141828218194,
        max_grad_norm=4.030765205694794,
        dropout_rate=0.24473038620786253,

        lr_factor=0.7921321619603106,
        lr_patience=49,
        lr_cooldown=7,
        lr_threshold=0.1,
        lr_min_lr=1e-6,

        train_batch_size=64,
        num_epochs=299
):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Equipment used: {device}")

    #
    if dataset not in ["PC-3", "MCF-7"]:
        print("Error: Only support PC-3 and MCF-7 for AUC experiment!")
        sys.exit()

    graphs, num_node_classes, num_class_of_dataset, degree_of_all_graphs = load_data_ori(dataset, data_path)
    print("Data loading completed!")

    start = time.time()

    node_enbed, graph_embeds, _, _, num_concept_all_deep = compute_bert_feats(
        graphs, maxh, depth,
        num_node_classes=num_node_classes,
        dataset=dataset,
        num_class_of_dataset=num_class_of_dataset,
        degree_of_all_graphs=degree_of_all_graphs,
        random_state=random_state, label_type=label_type,
        size=size, epoch=epoch, layer=layer, head=head,
        save_model=save_model, out_batch_size=out_batch_size,
        max_length=max_length, device=device
    )

    concept = [np.array(row) for row in np.hstack([sub for sub in graph_embeds]).tolist()]
    Data_graphs = []
    for i, g in enumerate(graphs):
        g.graph["concept_lbl"] = concept[i]
        Data_g = convert_networkx_to_pyg(g, num_node_classes)
        Data_graphs.append(Data_g)

    if crossvalidation:
        g_y_labels = np.array([data.y.item() for data in Data_graphs])
        skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
        train_test_indices = []
        for train_idx, test_idx in skf.split(X=np.zeros(len(g_y_labels)), y=g_y_labels):
            train_test_indices.append((train_idx, test_idx))

        train_test_datasets = []
        for train_idx, test_idx in train_test_indices:
            train_dataset = [Data_graphs[i] for i in train_idx]
            test_dataset = [Data_graphs[i] for i in test_idx]
            train_test_datasets.append((train_dataset, test_dataset))

        train_test_loaders = []
        for train_dataset, test_dataset in train_test_datasets:
            train_loader = DataLoader(train_dataset, batch_size=train_batch_size, shuffle=True)
            test_loader = DataLoader(test_dataset, batch_size=train_batch_size, shuffle=False)
            train_test_loaders.append((train_loader, test_loader))
    else:
        print('Please set crossvalidation=True')
        sys.exit()

    epoch_aucs = [[] for _ in range(num_epochs)]
    epoch_auc = []

    for fold, (train_loader, test_loader) in enumerate(train_test_loaders, 1):
        print('='*60)
        print(f"Fold {fold} training starts")
        fold_auc_list = []

        model = GIN_P(
            hidden_channels=64,
            num_node_classes=num_node_classes,
            num_class_of_dataset=num_class_of_dataset,
            dropout_rate=dropout_rate,
            num_concept_all_deep=num_concept_all_deep
        ).to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
        criterion_mse = nn.MSELoss()

        scheduler = ReduceLROnPlateau(
            optimizer, mode='max', factor=lr_factor, patience=lr_patience,
            threshold=lr_threshold, cooldown=lr_cooldown, min_lr=lr_min_lr, verbose=True
        )

        def train(loader):
            model.train()
            total_loss = 0
            correct = 0
            for data in loader:
                data = data.to(device)
                concept_pred, out = model(data.x, data.edge_index, data.batch)

                loss_auc = ranking_loss(out, data.y.float())
                loss_concept = criterion_mse(concept_pred, data.concept_lbl)
                sparse_loss = sparse_reg_coef * torch.norm(model.sparse_lin.weight, p=1)
                loss = loss_auc + loss_concept + sparse_loss

                total_loss += loss.item()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
                optimizer.step()
                optimizer.zero_grad()

                pred_probs = torch.sigmoid(out)
                pred_labels = (pred_probs > 0.5).float()
                correct += int((pred_labels == data.y).sum())
            return total_loss / len(loader), correct / len(loader.dataset)

        def test(loader):
            model.eval()
            all_preds = []
            all_labels = []
            with torch.no_grad():
                for data in loader:
                    data = data.to(device)
                    _, out = model(data.x, data.edge_index, data.batch)
                    pred_probs = torch.sigmoid(out).cpu().numpy()
                    all_preds.append(pred_probs)
                    all_labels.append(data.y.cpu().numpy())

            all_preds = np.concatenate(all_preds)
            all_labels = np.concatenate(all_labels)
            auc = roc_auc_score(all_labels, all_preds)
            return auc

        for epoch in range(1, num_epochs + 1):
            train_loss, train_acc = train(train_loader)
            test_auc = test(test_loader)
            scheduler.step(test_auc)

            print(f'Epoch: {epoch:03d} | Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.4f} | Test AUC: {test_auc:.4f}')
            epoch_aucs[epoch-1].append(test_auc)
            if epoch % 5 == 0:
                fold_auc_list.append(test_auc)

        epoch_auc.append(fold_auc_list)
        print('='*60)

    #
    epoch_average_aucs = [np.mean(aucs) for aucs in epoch_aucs]
    best_epoch_auc = max(epoch_average_aucs)
    best_index = epoch_average_aucs.index(best_epoch_auc)
    best_fold_aucs = epoch_aucs[best_index]

    final_mean = np.mean(best_fold_aucs)
    final_std = np.std(best_fold_aucs)

    print("\n" + "="*60)
    print(f"10-Fold Final AUC-ROC: {final_mean:.4f} ± {final_std:.4f}")

    end = time.time()
    print(f"Total time: {end-start:.2f}s")
    return final_mean, final_std, end-start

# ==============================================
#
# ==============================================
DATASET_CONFIGS = {
    "PC-3": {
        "maxh": 5, "depth": 2, "out_batch_size": 512, "max_length": 113,
        "lr": 0.000132965214572995, "weight_decay": 0.00014817820606039095,
        "sparse_reg_coef": 0.00026471141828218194, "max_grad_norm": 4.030765205694794,
        "dropout_rate": 0.24473038620786253, "lr_factor": 0.7921321619603106,
        "lr_patience": 49, "lr_cooldown": 7
    },
    "MCF-7": {
        "maxh": 5, "depth": 2, "out_batch_size": 512, "max_length": 113,
        "lr": 0.000132965214572995, "weight_decay": 0.00014817820606039095,
        "sparse_reg_coef": 0.00026471141828218194, "max_grad_norm": 4.030765205694794,
        "dropout_rate": 0.24473038620786253, "lr_factor": 0.7921321619603106,
        "lr_patience": 49, "lr_cooldown": 7
    }
}

# ==============================================
#
# ==============================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="PC-3")
    args = parser.parse_args()

    config = DATASET_CONFIGS[args.dataset]
    mean_auc, std_auc, total_time = main(
        dataset=args.dataset,
        maxh=config["maxh"],
        depth=config["depth"],
        out_batch_size=config["out_batch_size"],
        max_length=config["max_length"],
        lr=config["lr"],
        weight_decay=config["weight_decay"],
        sparse_reg_coef=config["sparse_reg_coef"],
        max_grad_norm=config["max_grad_norm"],
        dropout_rate=config["dropout_rate"],
        lr_factor=config["lr_factor"],
        lr_patience=config["lr_patience"],
        lr_cooldown=config["lr_cooldown"]
    )

    print("\n" + "="*60)
    print(f"{args.dataset} Training completed!")
    print(f"Final AUC: {mean_auc:.4f} ± {std_auc:.4f}")